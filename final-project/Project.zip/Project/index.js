const express = require("express");
const jsdom = require("jsdom");
const { JSDOM } = jsdom;
const cors = require("cors");

const app = express();

app.use(cors());

app.use(function (req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept"
  );
  next();
});

app.use(express.static("public"));

app.get("/game", (req, res) => {
  const TIMEOUT_MS = 5000;

  const timeoutPromise = new Promise((_, reject) => {
    setTimeout(() => {
      reject("timeout expired");
    }, TIMEOUT_MS);
  });

  const promise = JSDOM.fromURL("https://playstation.com/").then((dom) => {
    const doc = dom.window.document;
    const firstIMGTag = doc.documentElement.getElementByTagName("img")[0];
    const imgUrl = firstIMGTag.getAttribute("src");
    return imgUrl;
  });

  const arrayOfPromises = [timeoutPromise, promise];

  Promise.race(arrayOfPromises)
    .then((value) => {
      res.end(value);
    })
    .catch((error) => {
      res.status(503).end(error);
    });
});

app.get("/psn", (req, res) => {
  res.send("ps game!");
});

app.listen(7000, () => {
  console.log("listening on port 7000");
});
