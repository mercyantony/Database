function makeRequest() {
  const myFetchPromise = fetch("/psn")
    .then((response) => {
      const p = response.text();
      return p;
    })
    .then((text) => console.log(text));

  return myFetchPromise;
}

makeRequest();

const button = document.getElementsByTagName("button")[0];

button.onclick = function () {
  fetch("/game")
    .then((response) => {
      return response.text();
    })
    .then((text) => {
      const img = document.createElement("img");
      img.setAttribute("src", text);
      document.body.appendChild(img);
    })
    .catch((error) => {
      alert(`error : ${error}`);
    });
};
